#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Time : 2020/9/28 16:20
# @Author : way
# @Site : 
# @Describe: 4600 万企业数据可视化

from data import SourceDataDemo


class CorpData(SourceDataDemo):

    def __init__(self):
        """
        按照 SourceDataDemo 的格式覆盖数据即可
        """
        super().__init__()
        self.title = '全国企业大数据'
        self.counter = {'name': '企业总数量（全国）', 'value': 46897675}
        self.counter2 = {'name': '企业总数量（一线城市）', 'value': 6805564}
        self.echart1_data = {
            'title': '行业分布',
            'data': [
                {
                    "name": "批发零售业",
                    "value": 16881396
                },
                {
                    "name": "制造行业",
                    "value": 6780200
                },
                {
                    "name": "租赁商务服务",
                    "value": 5358030
                },
                {
                    "name": "农林牧渔业",
                    "value": 3335899
                },
                {
                    "name": "住宿餐饮业",
                    "value": 2284813
                },
                {
                    "name": "建筑业",
                    "value": 2267361
                },
            ]
        }
        self.echart2_data = {
            'title': '省份分布',
            'data': [
                {
                    "name": "广东",
                    "value": 5635811
                },
                {
                    "name": "山东",
                    "value": 3972598
                },
                {
                    "name": "江苏",
                    "value": 3793522
                },
                {
                    "name": "河南",
                    "value": 2787866
                },
                {
                    "name": "河北",
                    "value": 2402739
                },
                {
                    "name": "四川",
                    "value": 2083448
                },
                {
                    "name": "浙江",
                    "value": 2047431
                },
                {
                    "name": "上海",
                    "value": 1863549
                },
                {
                    "name": "北京",
                    "value": 1717739
                },
                {
                    "name": "辽宁",
                    "value": 1658253
                }
            ]
        }
        self.echarts3_1_data = {
            'title': 'IT互联网行业',
            'data': [
                {"name": "软件和信息技术服务", "value": 977084},
                {"name": "电信、广播电视和卫星传输", "value": 106294},
                {"name": "互联网和相关服务", "value": 258712},
            ]
        }
        self.echarts3_2_data = {
            'title': '金融行业',
            'data': [
                {"name": "金融行业", "value": 45},
                {"name": "资本市场", "value": 172467},
                {"name": "货币金融", "value": 202444},
                {"name": "其他", "value": 57077},
                {"name": "保险", "value": 104538},
            ]
        }
        self.echarts3_3_data = {
            'title': '运输物流仓储',
            'data': [
                {"name": "铁路", "value": 3331},
                {"name": "邮政", "value": 118877},
                {"name": "道路", "value": 564787},
                {"name": "装卸搬运和运输代理", "value": 253375},
                {"name": "航空", "value": 8060},
                {"name": "水运", "value": 22755},
                {"name": "仓储", "value": 143798},
            ]
        }
        self.echart4_data = {
            'title': '新一线城市',
            'data': [
                {"name": "IT互联网行业", "value": [16839,22356,38262,33763,27436,20337,12178,34248,31356,50089,16040,16927,30420,7847,11937]},
                {"name": "房地产", "value": [13292,7770,17510,17584,14516,14485,9193,17220,10323,19205,15400,5051,12325,8481,9617]},
            ],
            'xAxis': ['青岛', '长沙', '重庆', '郑州', '西安', '苏州', '沈阳', '武汉', '杭州', '成都', '天津', '合肥', '南京', '佛山', '东莞'],
        }
        self.echart5_data = {
            'title': '厦门行业分布',
            'data': [
                {
                    "name": "批发零售业",
                    "value": 167346
                },
                {
                    "name": "租赁商务",
                    "value": 55939
                },
                {
                    "name": "制造行业",
                    "value": 45326
                },
                {
                    "name": "科学研究",
                    "value": 22382
                },
                {
                    "name": "住宿餐饮",
                    "value": 21885
                },
                {
                    "name": "IT互联网",
                    "value": 18796
                },
                {
                    "name": "建筑业",
                    "value": 15244
                },
                {
                    "name": "居民服务",
                    "value": 12470
                }
            ]
        }
        self.echart6_data = {
            'title': '一线城市',
            'data': [
                {"name": "北京", "value": 1717739, "value2": 2000000 - 1717739, "color": "01", "radius": ['59%', '70%']},
                {"name": "上海", "value": 1863549, "value2": 2000000 - 1863549, "color": "02", "radius": ['49%', '60%']},
                {"name": "广州", "value": 1261475, "value2": 2000000 - 1261475, "color": "03", "radius": ['39%', '50%']},
                {"name": "深圳", "value": 1962801, "value2": 2000000 - 1962801, "color": "05", "radius": ['30%', '40%']},
            ]
        }
        self.map_1_data = {
            'symbolSize': 80000,
            'data': [
                {
                    "name": "舟山新区",
                    "value": 161
                },
                {
                    "name": "忻州",
                    "value": 70784
                },
                {
                    "name": "什邡",
                    "value": 3
                },
                {
                    "name": "哈密地区",
                    "value": 5
                },
                {
                    "name": "通辽",
                    "value": 85136
                },
                {
                    "name": "潍坊",
                    "value": 397874
                },
                {
                    "name": "保山",
                    "value": 48480
                },
                {
                    "name": "海宁",
                    "value": 1
                },
                {
                    "name": "仪征",
                    "value": 1
                },
                {
                    "name": "九江",
                    "value": 115899
                },
                {
                    "name": "耒阳",
                    "value": 5
                },
                {
                    "name": "景德镇",
                    "value": 28611
                },
                {
                    "name": "宿州",
                    "value": 80494
                },
                {
                    "name": "博尔塔拉蒙古自治州",
                    "value": 1
                },
                {
                    "name": "义马",
                    "value": 2
                },
                {
                    "name": "枣庄",
                    "value": 120614
                },
                {
                    "name": "怀化",
                    "value": 48647
                },
                {
                    "name": "新界",
                    "value": 329
                },
                {
                    "name": "阿勒泰地区",
                    "value": 2
                },
                {
                    "name": "自贡",
                    "value": 41452
                },
                {
                    "name": "营口",
                    "value": 108605
                },
                {
                    "name": "河源",
                    "value": 56177
                },
                {
                    "name": "威海",
                    "value": 136179
                },
                {
                    "name": "商洛",
                    "value": 39144
                },
                {
                    "name": "瑞丽",
                    "value": 1
                },
                {
                    "name": "焦作",
                    "value": 98645
                },
                {
                    "name": "北京",
                    "value": 1717739
                },
                {
                    "name": "鹤壁",
                    "value": 42904
                },
                {
                    "name": "宣城",
                    "value": 49005
                },
                {
                    "name": "淮南",
                    "value": 54726
                },
                {
                    "name": "昭通",
                    "value": 54965
                },
                {
                    "name": "万宁",
                    "value": 2334
                },
                {
                    "name": "铜陵",
                    "value": 31045
                },
                {
                    "name": "青岛莱西",
                    "value": 27
                },
                {
                    "name": "太仓",
                    "value": 15
                },
                {
                    "name": "韩城",
                    "value": 6
                },
                {
                    "name": "镇江",
                    "value": 151969
                },
                {
                    "name": "图木舒克",
                    "value": 869
                },
                {
                    "name": "宜昌",
                    "value": 106418
                },
                {
                    "name": "五指山",
                    "value": 757
                },
                {
                    "name": "吕梁",
                    "value": 85168
                },
                {
                    "name": "达州",
                    "value": 69415
                },
                {
                    "name": "牡丹江",
                    "value": 69489
                },
                {
                    "name": "溧阳",
                    "value": 1
                },
                {
                    "name": "黄冈",
                    "value": 101061
                },
                {
                    "name": "荆州",
                    "value": 86955
                },
                {
                    "name": "芜湖",
                    "value": 71639
                },
                {
                    "name": "新北",
                    "value": 4997
                },
                {
                    "name": "衡水",
                    "value": 143528
                },
                {
                    "name": "乐平",
                    "value": 5
                },
                {
                    "name": "和田",
                    "value": 46014
                },
                {
                    "name": "玉溪",
                    "value": 62841
                },
                {
                    "name": "吉林",
                    "value": 119684
                },
                {
                    "name": "晋州",
                    "value": 2
                },
                {
                    "name": "益阳",
                    "value": 67738
                },
                {
                    "name": "周口",
                    "value": 153687
                },
                {
                    "name": "商丘",
                    "value": 162361
                },
                {
                    "name": "海口",
                    "value": 203141
                },
                {
                    "name": "合肥",
                    "value": 403592
                },
                {
                    "name": "林芝",
                    "value": 7348
                },
                {
                    "name": "张家港",
                    "value": 1
                },
                {
                    "name": "吐鲁番地区",
                    "value": 1
                },
                {
                    "name": "苏州",
                    "value": 761964
                },
                {
                    "name": "仁怀",
                    "value": 5
                },
                {
                    "name": "无锡",
                    "value": 388079
                },
                {
                    "name": "恩施",
                    "value": 75131
                },
                {
                    "name": "天长",
                    "value": 1
                },
                {
                    "name": "克拉玛依",
                    "value": 22459
                },
                {
                    "name": "泸州",
                    "value": 72283
                },
                {
                    "name": "栖霞",
                    "value": 2
                },
                {
                    "name": "津",
                    "value": 3
                },
                {
                    "name": "遵化",
                    "value": 1
                },
                {
                    "name": "濮阳",
                    "value": 92128
                },
                {
                    "name": "大兴安岭地区",
                    "value": 60
                },
                {
                    "name": "新乡",
                    "value": 157152
                },
                {
                    "name": "随州",
                    "value": 38572
                },
                {
                    "name": "湖州",
                    "value": 79596
                },
                {
                    "name": "东阳",
                    "value": 6
                },
                {
                    "name": "鄂州",
                    "value": 27036
                },
                {
                    "name": "德阳",
                    "value": 66709
                },
                {
                    "name": "银川",
                    "value": 113991
                },
                {
                    "name": "天津",
                    "value": 604965
                },
                {
                    "name": "三明",
                    "value": 77702
                },
                {
                    "name": "阿拉尔",
                    "value": 1935
                },
                {
                    "name": "龙泉",
                    "value": 34
                },
                {
                    "name": "成都",
                    "value": 924643
                },
                {
                    "name": "威海荣成",
                    "value": 1
                },
                {
                    "name": "天水",
                    "value": 54557
                },
                {
                    "name": "平顶山",
                    "value": 124198
                },
                {
                    "name": "那曲",
                    "value": 5801
                },
                {
                    "name": "台中",
                    "value": 3818
                },
                {
                    "name": "吴忠",
                    "value": 55558
                },
                {
                    "name": "枣庄滕州",
                    "value": 8
                },
                {
                    "name": "株洲",
                    "value": 70012
                },
                {
                    "name": "兰州",
                    "value": 253776
                },
                {
                    "name": "新余",
                    "value": 34755
                },
                {
                    "name": "葫芦岛",
                    "value": 76596
                },
                {
                    "name": "阿里",
                    "value": 2130
                },
                {
                    "name": "鸡西",
                    "value": 41768
                },
                {
                    "name": "鄂尔多斯",
                    "value": 86527
                },
                {
                    "name": "黔东南",
                    "value": 110295
                },
                {
                    "name": "东莞",
                    "value": 645252
                },
                {
                    "name": "邵阳",
                    "value": 59109
                },
                {
                    "name": "瓦房店",
                    "value": 92
                },
                {
                    "name": "莱西",
                    "value": 2
                },
                {
                    "name": "开远",
                    "value": 1
                },
                {
                    "name": "酒泉",
                    "value": 55168
                },
                {
                    "name": "莱阳",
                    "value": 1
                },
                {
                    "name": "滨州",
                    "value": 147474
                },
                {
                    "name": "遂宁",
                    "value": 49076
                },
                {
                    "name": "青岛",
                    "value": 659581
                },
                {
                    "name": "甘孜藏族自治州",
                    "value": 3
                },
                {
                    "name": "黄石",
                    "value": 56620
                },
                {
                    "name": "西双版纳傣族自治州",
                    "value": 2
                },
                {
                    "name": "开封",
                    "value": 123452
                },
                {
                    "name": "抚顺",
                    "value": 61732
                },
                {
                    "name": "潮州",
                    "value": 33591
                },
                {
                    "name": "澳门",
                    "value": 310
                },
                {
                    "name": "新竹",
                    "value": 2282
                },
                {
                    "name": "贵阳",
                    "value": 310432
                },
                {
                    "name": "基隆",
                    "value": 541
                },
                {
                    "name": "长春",
                    "value": 307034
                },
                {
                    "name": "呼伦贝尔",
                    "value": 76834
                },
                {
                    "name": "鹤岗",
                    "value": 26312
                },
                {
                    "name": "南充",
                    "value": 91426
                },
                {
                    "name": "青岛平度",
                    "value": 5
                },
                {
                    "name": "介休",
                    "value": 3
                },
                {
                    "name": "海安",
                    "value": 1
                },
                {
                    "name": "迪庆",
                    "value": 16730
                },
                {
                    "name": "南投",
                    "value": 296
                },
                {
                    "name": "香港",
                    "value": 2048
                },
                {
                    "name": "大安",
                    "value": 8
                },
                {
                    "name": "秦皇岛",
                    "value": 101000
                },
                {
                    "name": "阿克苏地区",
                    "value": 2
                },
                {
                    "name": "贺州",
                    "value": 37990
                },
                {
                    "name": "泰安",
                    "value": 154160
                },
                {
                    "name": "凉山",
                    "value": 61398
                },
                {
                    "name": "玉林",
                    "value": 111684
                },
                {
                    "name": "清远",
                    "value": 73871
                },
                {
                    "name": "武威",
                    "value": 48458
                },
                {
                    "name": "邢台",
                    "value": 217437
                },
                {
                    "name": "延安",
                    "value": 69234
                },
                {
                    "name": "白沙",
                    "value": 7
                },
                {
                    "name": "乌海",
                    "value": 19163
                },
                {
                    "name": "襄阳",
                    "value": 119937
                },
                {
                    "name": "济宁",
                    "value": 283287
                },
                {
                    "name": "洪湖",
                    "value": 1
                },
                {
                    "name": "莱芜",
                    "value": 34402
                },
                {
                    "name": "建瓯",
                    "value": 31
                },
                {
                    "name": "路环岛",
                    "value": 11
                },
                {
                    "name": "雅安",
                    "value": 42091
                },
                {
                    "name": "靖西",
                    "value": 1
                },
                {
                    "name": "博尔塔拉蒙古",
                    "value": 79
                },
                {
                    "name": "宁德",
                    "value": 94732
                },
                {
                    "name": "永州",
                    "value": 60735
                },
                {
                    "name": "阳泉",
                    "value": 53255
                },
                {
                    "name": "怒江",
                    "value": 9293
                },
                {
                    "name": "楚雄彝族自治州",
                    "value": 4
                },
                {
                    "name": "定西",
                    "value": 52645
                },
                {
                    "name": "荣成",
                    "value": 2
                },
                {
                    "name": "凯里",
                    "value": 27
                },
                {
                    "name": "武汉",
                    "value": 592203
                },
                {
                    "name": "德宏",
                    "value": 33889
                },
                {
                    "name": "海西",
                    "value": 19682
                },
                {
                    "name": "哈尔滨",
                    "value": 310698
                },
                {
                    "name": "大庆",
                    "value": 83772
                },
                {
                    "name": "果洛",
                    "value": 2621
                },
                {
                    "name": "丹阳",
                    "value": 1
                },
                {
                    "name": "上饶",
                    "value": 111455
                },
                {
                    "name": "锦州",
                    "value": 90246
                },
                {
                    "name": "莆田",
                    "value": 82285
                },
                {
                    "name": "吐鲁番",
                    "value": 27846
                },
                {
                    "name": "漯河",
                    "value": 61549
                },
                {
                    "name": "大连",
                    "value": 382440
                },
                {
                    "name": "阿克苏",
                    "value": 59736
                },
                {
                    "name": "红河哈尼族彝族自治州",
                    "value": 1
                },
                {
                    "name": "浏阳",
                    "value": 2
                },
                {
                    "name": "河池",
                    "value": 81167
                },
                {
                    "name": "潜江",
                    "value": 2189
                },
                {
                    "name": "冷水江",
                    "value": 1
                },
                {
                    "name": "阜新",
                    "value": 64873
                },
                {
                    "name": "昌吉",
                    "value": 63572
                },
                {
                    "name": "山南",
                    "value": 8697
                },
                {
                    "name": "·苏州",
                    "value": 1
                },
                {
                    "name": "白城",
                    "value": 58985
                },
                {
                    "name": "慈溪",
                    "value": 3
                },
                {
                    "name": "蛟河",
                    "value": 2
                },
                {
                    "name": "宿迁",
                    "value": 174059
                },
                {
                    "name": "茂名高州",
                    "value": 1
                },
                {
                    "name": "铜川",
                    "value": 24539
                },
                {
                    "name": "五家渠",
                    "value": 681
                },
                {
                    "name": "驻马店",
                    "value": 140282
                },
                {
                    "name": "曲阜",
                    "value": 1
                },
                {
                    "name": "阳春",
                    "value": 1
                },
                {
                    "name": "铁岭",
                    "value": 71673
                },
                {
                    "name": "黔西南",
                    "value": 84647
                },
                {
                    "name": "聊城",
                    "value": 181255
                },
                {
                    "name": "遵义",
                    "value": 197671
                },
                {
                    "name": "包头",
                    "value": 100157
                },
                {
                    "name": "重庆",
                    "value": 915432
                },
                {
                    "name": "厦门",
                    "value": 398539
                },
                {
                    "name": "伊犁哈萨克自治州",
                    "value": 2
                },
                {
                    "name": "嘉峪关",
                    "value": 13611
                },
                {
                    "name": "三沙",
                    "value": 636
                },
                {
                    "name": "延吉",
                    "value": 9
                },
                {
                    "name": "佛山",
                    "value": 375132
                },
                {
                    "name": "杭州",
                    "value": 456397
                },
                {
                    "name": "赤峰",
                    "value": 122882
                },
                {
                    "name": "彭州",
                    "value": 12
                },
                {
                    "name": "哈密",
                    "value": 32820
                },
                {
                    "name": "济南",
                    "value": 433494
                },
                {
                    "name": "曲靖",
                    "value": 87475
                },
                {
                    "name": "阿拉善盟",
                    "value": 8226
                },
                {
                    "name": "安宁",
                    "value": 3
                },
                {
                    "name": "泉州",
                    "value": 318003
                },
                {
                    "name": "东台",
                    "value": 3
                },
                {
                    "name": "岳阳",
                    "value": 66368
                },
                {
                    "name": "绥化",
                    "value": 90282
                },
                {
                    "name": "昆明",
                    "value": 327619
                },
                {
                    "name": "日喀则",
                    "value": 25130
                },
                {
                    "name": "桃园",
                    "value": 3955
                },
                {
                    "name": "金华",
                    "value": 280396
                },
                {
                    "name": "伊犁哈萨克",
                    "value": 178
                },
                {
                    "name": "江阴",
                    "value": 16
                },
                {
                    "name": "安康",
                    "value": 58798
                },
                {
                    "name": "荆门",
                    "value": 53163
                },
                {
                    "name": "烟台",
                    "value": 291537
                },
                {
                    "name": "定州",
                    "value": 7
                },
                {
                    "name": "丽江",
                    "value": 35610
                },
                {
                    "name": "绵竹",
                    "value": 4
                },
                {
                    "name": "许昌",
                    "value": 119450
                },
                {
                    "name": "宁乡",
                    "value": 1
                },
                {
                    "name": "晋城",
                    "value": 60737
                },
                {
                    "name": "长沙",
                    "value": 346142
                },
                {
                    "name": "韶关",
                    "value": 49216
                },
                {
                    "name": "江门",
                    "value": 109733
                },
                {
                    "name": "德宏州芒",
                    "value": 6
                },
                {
                    "name": "福州",
                    "value": 306310
                },
                {
                    "name": "中卫",
                    "value": 34127
                },
                {
                    "name": "蚌埠",
                    "value": 57339
                },
                {
                    "name": "昌吉回族自治州",
                    "value": 1
                },
                {
                    "name": "呼和浩",
                    "value": 1
                },
                {
                    "name": "台州",
                    "value": 172156
                },
                {
                    "name": "柳州",
                    "value": 118680
                },
                {
                    "name": "揭阳",
                    "value": 49581
                },
                {
                    "name": "大石桥",
                    "value": 1
                },
                {
                    "name": "渭南",
                    "value": 89260
                },
                {
                    "name": "巴音郭楞",
                    "value": 34170
                },
                {
                    "name": "温州",
                    "value": 277937
                },
                {
                    "name": "北海",
                    "value": 57863
                },
                {
                    "name": "湘乡",
                    "value": 3
                },
                {
                    "name": "淮北",
                    "value": 43925
                },
                {
                    "name": "石河子",
                    "value": 5755
                },
                {
                    "name": "禹州",
                    "value": 2
                },
                {
                    "name": "拉萨",
                    "value": 44479
                },
                {
                    "name": "湘潭",
                    "value": 36361
                },
                {
                    "name": "北屯",
                    "value": 668
                },
                {
                    "name": "晋江",
                    "value": 1
                },
                {
                    "name": "龙口",
                    "value": 1
                },
                {
                    "name": "菏泽",
                    "value": 228000
                },
                {
                    "name": "汕尾",
                    "value": 28297
                },
                {
                    "name": "龙岩",
                    "value": 71382
                },
                {
                    "name": "延边朝鲜族自治州",
                    "value": 361
                },
                {
                    "name": "郑州",
                    "value": 723262
                },
                {
                    "name": "漳州",
                    "value": 116658
                },
                {
                    "name": "宝鸡",
                    "value": 98799
                },
                {
                    "name": "屏东",
                    "value": 1469
                },
                {
                    "name": "福安",
                    "value": 8
                },
                {
                    "name": "南宁",
                    "value": 361448
                },
                {
                    "name": "三门峡",
                    "value": 51541
                },
                {
                    "name": "克孜勒苏",
                    "value": 13951
                },
                {
                    "name": "利川",
                    "value": 1
                },
                {
                    "name": "抚远",
                    "value": 1
                },
                {
                    "name": "榆林",
                    "value": 121829
                },
                {
                    "name": "黄南",
                    "value": 36480
                },
                {
                    "name": "攀枝花",
                    "value": 31558
                },
                {
                    "name": "衢州",
                    "value": 50415
                },
                {
                    "name": "呼和浩特",
                    "value": 129686
                },
                {
                    "name": "大理",
                    "value": 62322
                },
                {
                    "name": "沅江",
                    "value": 7
                },
                {
                    "name": "高雄县",
                    "value": 1
                },
                {
                    "name": "东方",
                    "value": 2127
                },
                {
                    "name": "双鸭山",
                    "value": 31647
                },
                {
                    "name": "喀什地区",
                    "value": 2
                },
                {
                    "name": "吉安",
                    "value": 83869
                },
                {
                    "name": "章丘",
                    "value": 2
                },
                {
                    "name": "崇左",
                    "value": 47117
                },
                {
                    "name": "黔南",
                    "value": 115937
                },
                {
                    "name": "保亭",
                    "value": 7
                },
                {
                    "name": "广州",
                    "value": 1261475
                },
                {
                    "name": "海阳",
                    "value": 1
                },
                {
                    "name": "德兴",
                    "value": 1
                },
                {
                    "name": "都匀",
                    "value": 5
                },
                {
                    "name": "巴彦淖尔",
                    "value": 47338
                },
                {
                    "name": "内江",
                    "value": 50568
                },
                {
                    "name": "云浮",
                    "value": 34606
                },
                {
                    "name": "珠海",
                    "value": 72002
                },
                {
                    "name": "舟山",
                    "value": 29005
                },
                {
                    "name": "萍乡",
                    "value": 36176
                },
                {
                    "name": "滁州",
                    "value": 78841
                },
                {
                    "name": "儋州",
                    "value": 21576
                },
                {
                    "name": "吉首",
                    "value": 9
                },
                {
                    "name": "贵溪",
                    "value": 1
                },
                {
                    "name": "西双版纳",
                    "value": 31239
                },
                {
                    "name": "深圳",
                    "value": 1962801
                },
                {
                    "name": "高雄",
                    "value": 4459
                },
                {
                    "name": "湘西",
                    "value": 35582
                },
                {
                    "name": "宜兰",
                    "value": 868
                },
                {
                    "name": "宜春",
                    "value": 106453
                },
                {
                    "name": "济源",
                    "value": 3730
                },
                {
                    "name": "常德",
                    "value": 60603
                },
                {
                    "name": "昆山",
                    "value": 14
                },
                {
                    "name": "四平",
                    "value": 72288
                },
                {
                    "name": "梅州",
                    "value": 84115
                },
                {
                    "name": "红河",
                    "value": 62677
                },
                {
                    "name": "莱州",
                    "value": 2
                },
                {
                    "name": "金昌",
                    "value": 18695
                },
                {
                    "name": "玉环",
                    "value": 7
                },
                {
                    "name": "阿勒泰",
                    "value": 25001
                },
                {
                    "name": "云林",
                    "value": 245
                },
                {
                    "name": "彰化",
                    "value": 1493
                },
                {
                    "name": "梧州",
                    "value": 54510
                },
                {
                    "name": "贵港",
                    "value": 87421
                },
                {
                    "name": "蓬莱",
                    "value": 7
                },
                {
                    "name": "余姚",
                    "value": 8
                },
                {
                    "name": "唐山",
                    "value": 185652
                },
                {
                    "name": "安顺",
                    "value": 71378
                },
                {
                    "name": "瑞安",
                    "value": 4
                },
                {
                    "name": "博尔塔拉",
                    "value": 18801
                },
                {
                    "name": "仙桃",
                    "value": 3421
                },
                {
                    "name": "齐齐哈尔",
                    "value": 102513
                },
                {
                    "name": "兴城",
                    "value": 1
                },
                {
                    "name": "个旧",
                    "value": 3
                },
                {
                    "name": "新乐",
                    "value": 1
                },
                {
                    "name": "池州",
                    "value": 28860
                },
                {
                    "name": "招远",
                    "value": 4
                },
                {
                    "name": "沈阳",
                    "value": 365337
                },
                {
                    "name": "宁波",
                    "value": 331901
                },
                {
                    "name": "七台河",
                    "value": 17896
                },
                {
                    "name": "大同",
                    "value": 69158
                },
                {
                    "name": "",
                    "value": 103104
                },
                {
                    "name": "六盘水",
                    "value": 97941
                },
                {
                    "name": "湛江吴川",
                    "value": 1
                },
                {
                    "name": "湘西土家族苗族自治州",
                    "value": 273
                },
                {
                    "name": "固原",
                    "value": 27618
                },
                {
                    "name": "通化",
                    "value": 53376
                },
                {
                    "name": "福鼎",
                    "value": 3
                },
                {
                    "name": "\\N",
                    "value": 43900
                },
                {
                    "name": "防城港",
                    "value": 33483
                },
                {
                    "name": "大兴安岭",
                    "value": 9957
                },
                {
                    "name": "西安",
                    "value": 483001
                },
                {
                    "name": "南阳",
                    "value": 198209
                },
                {
                    "name": "茂名",
                    "value": 88878
                },
                {
                    "name": "张家口",
                    "value": 107397
                },
                {
                    "name": "赣州",
                    "value": 161595
                },
                {
                    "name": "桂林",
                    "value": 125532
                },
                {
                    "name": "北区",
                    "value": 2
                },
                {
                    "name": "诸暨",
                    "value": 1
                },
                {
                    "name": "运城",
                    "value": 216181
                },
                {
                    "name": "丹东",
                    "value": 78563
                },
                {
                    "name": "张掖",
                    "value": 56638
                },
                {
                    "name": "淄博",
                    "value": 190065
                },
                {
                    "name": "海门",
                    "value": 9
                },
                {
                    "name": "廊坊",
                    "value": 176743
                },
                {
                    "name": "甘南",
                    "value": 21298
                },
                {
                    "name": "平凉",
                    "value": 51979
                },
                {
                    "name": "巴音郭楞蒙古自治州",
                    "value": 1
                },
                {
                    "name": "沧州",
                    "value": 232646
                },
                {
                    "name": "毕节",
                    "value": 133659
                },
                {
                    "name": "乌兰察布",
                    "value": 44915
                },
                {
                    "name": "百色",
                    "value": 80859
                },
                {
                    "name": "汕头",
                    "value": 90525
                },
                {
                    "name": "苗栗",
                    "value": 2804
                },
                {
                    "name": "长治",
                    "value": 87575
                },
                {
                    "name": "楚雄",
                    "value": 52923
                },
                {
                    "name": "延边",
                    "value": 71577
                },
                {
                    "name": "伊春",
                    "value": 23486
                },
                {
                    "name": "台东",
                    "value": 1812
                },
                {
                    "name": "连江",
                    "value": 2504
                },
                {
                    "name": "涿州",
                    "value": 1
                },
                {
                    "name": "台北",
                    "value": 2664
                },
                {
                    "name": "永济",
                    "value": 6
                },
                {
                    "name": "如皋",
                    "value": 18
                },
                {
                    "name": "南平",
                    "value": 69163
                },
                {
                    "name": "兴安盟",
                    "value": 29136
                },
                {
                    "name": "东营",
                    "value": 102950
                },
                {
                    "name": "郴州",
                    "value": 67193
                },
                {
                    "name": "连云港",
                    "value": 124099
                },
                {
                    "name": "十堰",
                    "value": 76953
                },
                {
                    "name": "邵武",
                    "value": 3
                },
                {
                    "name": "永康",
                    "value": 11
                },
                {
                    "name": "阜阳",
                    "value": 134105
                },
                {
                    "name": "海南",
                    "value": 12363
                },
                {
                    "name": "中山",
                    "value": 220405
                },
                {
                    "name": "石嘴山",
                    "value": 20943
                },
                {
                    "name": "安阳",
                    "value": 137007
                },
                {
                    "name": "辽源",
                    "value": 24345
                },
                {
                    "name": "娄底",
                    "value": 47728
                },
                {
                    "name": "朝阳",
                    "value": 96081
                },
                {
                    "name": "来宾",
                    "value": 48133
                },
                {
                    "name": "锡林郭勒盟",
                    "value": 30830
                },
                {
                    "name": "克孜勒苏柯尔克孜自治州",
                    "value": 1
                },
                {
                    "name": "扬州",
                    "value": 178676
                },
                {
                    "name": "汉中",
                    "value": 77816
                },
                {
                    "name": "马鞍山",
                    "value": 51262
                },
                {
                    "name": "佳木斯",
                    "value": 65312
                },
                {
                    "name": "太原",
                    "value": 225524
                },
                {
                    "name": "乌鲁木齐",
                    "value": 210305
                },
                {
                    "name": "淮安",
                    "value": 143911
                },
                {
                    "name": "临沂",
                    "value": 303072
                },
                {
                    "name": "白山",
                    "value": 32733
                },
                {
                    "name": "花莲",
                    "value": 7048
                },
                {
                    "name": "九龙",
                    "value": 621
                },
                {
                    "name": "辛集",
                    "value": 5
                },
                {
                    "name": "绵阳",
                    "value": 145249
                },
                {
                    "name": "海北",
                    "value": 7581
                },
                {
                    "name": "西宁",
                    "value": 98399
                },
                {
                    "name": "乐山",
                    "value": 61810
                },
                {
                    "name": "阳江",
                    "value": 41090
                },
                {
                    "name": "澳门半岛",
                    "value": 27
                },
                {
                    "name": "伊犁",
                    "value": 99483
                },
                {
                    "name": "眉山",
                    "value": 53762
                },
                {
                    "name": "乐清",
                    "value": 1
                },
                {
                    "name": "福泉",
                    "value": 1
                },
                {
                    "name": "钦州",
                    "value": 58499
                },
                {
                    "name": "普兰店",
                    "value": 5
                },
                {
                    "name": "广汉",
                    "value": 17
                },
                {
                    "name": "广安",
                    "value": 51019
                },
                {
                    "name": "蒙自",
                    "value": 2
                },
                {
                    "name": "兴安",
                    "value": 15625
                },
                {
                    "name": "澎湖",
                    "value": 1073
                },
                {
                    "name": "老河口",
                    "value": 2
                },
                {
                    "name": "喀什",
                    "value": 100640
                },
                {
                    "name": "宜宾",
                    "value": 86251
                },
                {
                    "name": "临汾",
                    "value": 96106
                },
                {
                    "name": "咸阳",
                    "value": 81727
                },
                {
                    "name": "洛阳",
                    "value": 246276
                },
                {
                    "name": "湛江",
                    "value": 85558
                },
                {
                    "name": "天门",
                    "value": 2943
                },
                {
                    "name": "大理白族自治州",
                    "value": 2
                },
                {
                    "name": "台南",
                    "value": 3427
                },
                {
                    "name": "张家界",
                    "value": 19919
                },
                {
                    "name": "信阳",
                    "value": 144594
                },
                {
                    "name": "德州",
                    "value": 180884
                },
                {
                    "name": "盐城",
                    "value": 214803
                },
                {
                    "name": "阿坝藏族羌族自治州",
                    "value": 6
                },
                {
                    "name": "承德",
                    "value": 89533
                },
                {
                    "name": "怒江傈僳族",
                    "value": 50
                },
                {
                    "name": "广元",
                    "value": 47565
                },
                {
                    "name": "凌源",
                    "value": 1
                },
                {
                    "name": "庆阳",
                    "value": 82780
                },
                {
                    "name": "本溪",
                    "value": 39920
                },
                {
                    "name": "盘州",
                    "value": 2
                },
                {
                    "name": "昌都",
                    "value": 9701
                },
                {
                    "name": "肇庆",
                    "value": 70831
                },
                {
                    "name": "永安",
                    "value": 1
                },
                {
                    "name": "绍兴",
                    "value": 150535
                },
                {
                    "name": "咸宁",
                    "value": 57352
                },
                {
                    "name": "启东",
                    "value": 3
                },
                {
                    "name": "临夏",
                    "value": 26427
                },
                {
                    "name": "鹰潭",
                    "value": 24227
                },
                {
                    "name": "琼海",
                    "value": 2844
                },
                {
                    "name": "桦甸",
                    "value": 5
                },
                {
                    "name": "省直辖县级行政区划",
                    "value": 4
                },
                {
                    "name": "海东",
                    "value": 28380
                },
                {
                    "name": "文昌",
                    "value": 2806
                },
                {
                    "name": "日照",
                    "value": 124225
                },
                {
                    "name": "玉树",
                    "value": 5089
                },
                {
                    "name": "台山",
                    "value": 1
                },
                {
                    "name": "泰州",
                    "value": 177028
                },
                {
                    "name": "黑河",
                    "value": 40173
                },
                {
                    "name": "高安",
                    "value": 3
                },
                {
                    "name": "南京",
                    "value": 647986
                },
                {
                    "name": "铜仁",
                    "value": 104984
                },
                {
                    "name": "盘锦",
                    "value": 61232
                },
                {
                    "name": "临沧",
                    "value": 40346
                },
                {
                    "name": "格尔木",
                    "value": 13
                },
                {
                    "name": "邹城",
                    "value": 1
                },
                {
                    "name": "三亚",
                    "value": 60867
                },
                {
                    "name": "南通",
                    "value": 241594
                },
                {
                    "name": "新郑",
                    "value": 1
                },
                {
                    "name": "金门",
                    "value": 1742
                },
                {
                    "name": "朔州",
                    "value": 46142
                },
                {
                    "name": "辽阳",
                    "value": 63291
                },
                {
                    "name": "鞍山",
                    "value": 97244
                },
                {
                    "name": "上海",
                    "value": 1863549
                },
                {
                    "name": "甘孜",
                    "value": 19541
                },
                {
                    "name": "常州溧阳",
                    "value": 1
                },
                {
                    "name": "塔城",
                    "value": 36759
                },
                {
                    "name": "普洱",
                    "value": 42527
                },
                {
                    "name": "抚州",
                    "value": 62608
                },
                {
                    "name": "邯郸",
                    "value": 241393
                },
                {
                    "name": "孝感",
                    "value": 69045
                },
                {
                    "name": "锡林郭勒",
                    "value": 24224
                },
                {
                    "name": "黄山",
                    "value": 28771
                },
                {
                    "name": "江都",
                    "value": 1
                },
                {
                    "name": "克孜勒苏柯尔克孜",
                    "value": 37
                },
                {
                    "name": "白银",
                    "value": 56861
                },
                {
                    "name": "吴江",
                    "value": 1
                },
                {
                    "name": "塔城地区",
                    "value": 3
                },
                {
                    "name": "新沂",
                    "value": 4
                },
                {
                    "name": "大丰",
                    "value": 1
                },
                {
                    "name": "峨眉山",
                    "value": 1
                },
                {
                    "name": "晋中",
                    "value": 83694
                },
                {
                    "name": "巢湖",
                    "value": 1
                },
                {
                    "name": "襄樊",
                    "value": 1
                },
                {
                    "name": "徐州",
                    "value": 287766
                },
                {
                    "name": "资阳",
                    "value": 38014
                },
                {
                    "name": "惠州",
                    "value": 200040
                },
                {
                    "name": "南昌",
                    "value": 199212
                },
                {
                    "name": "文山",
                    "value": 52728
                },
                {
                    "name": "安庆",
                    "value": 82570
                },
                {
                    "name": "嘉义",
                    "value": 981
                },
                {
                    "name": "亳州",
                    "value": 100402
                },
                {
                    "name": "文山壮族苗族自治州",
                    "value": 1
                },
                {
                    "name": "六安",
                    "value": 72144
                },
                {
                    "name": "衡阳",
                    "value": 66911
                },
                {
                    "name": "石家庄",
                    "value": 571662
                },
                {
                    "name": "瑞金",
                    "value": 12
                },
                {
                    "name": "资兴",
                    "value": 4
                },
                {
                    "name": "保定",
                    "value": 332971
                },
                {
                    "name": "陇南",
                    "value": 60613
                },
                {
                    "name": "都江堰",
                    "value": 1
                },
                {
                    "name": "丽水",
                    "value": 56140
                },
                {
                    "name": "义乌",
                    "value": 3
                },
                {
                    "name": "常熟",
                    "value": 2
                },
                {
                    "name": "阿拉善",
                    "value": 7645
                },
                {
                    "name": "兰溪",
                    "value": 3
                },
                {
                    "name": "松原",
                    "value": 58316
                },
                {
                    "name": "嘉兴",
                    "value": 156218
                },
                {
                    "name": "深州",
                    "value": 2
                },
                {
                    "name": "巴中",
                    "value": 55348
                },
                {
                    "name": "常州",
                    "value": 295863
                },
                {
                    "name": "阿坝",
                    "value": 23804
                },
                {
                    "name": "巴音郭楞蒙古",
                    "value": 3117
                },
                {
                    "name": "滕州",
                    "value": 2
                }
            ]
        }

