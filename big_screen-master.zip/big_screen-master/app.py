# -*- coding: utf-8 -*-
# @Time : 2020/8/26 14:48
# @Author : way
# @Site :
# @Describe:

from flask import Flask, render_template
from data import SourceData
from data_corp import CorpData
from data_job import JobData
from gevent import pywsgi
import os

app = Flask(__name__)


@app.route('/')
def index():
    data = SourceData()
    return render_template('index.html', form=data, title=data.title)
#
#
# @app.route('/')
# def index():
#     data = SourceData()
#     html = render_template('index.html', form=data, title=data.title)  # 渲染模板
#     # filename = os.path.join(os.getcwd(), "D:\\SRTP\\big_screen-master\\static", 'index.html')  # 使用os.path.join()函数构建文件路径
#     # with open(filename, 'w') as f:  # 打开文件并写入HTML内容
#     #     f.write(html)
#     return html
#
#
# if __name__ == '__main__':
#     app.run()
# @app.route("/save_html")
# def save_html():
#     # 获取模板 HTML 内容
#     html = render_template("index.html")
#
#     # 将 HTML 写入文件
#     with open("index1.html", "w") as file:
#         file.write(html)
#
#     # 返回保存成功的消息
#     return "HTML 已保存到本地"


@app.route('/corp')
def corp():
    data = CorpData()
    return render_template('index.html', form=data, title=data.title)


@app.route('/job')
def job():
    data = JobData()
    return render_template('index.html', form=data, title=data.title)


if __name__ == "__main__":
    app.run(host='127.0.0.1', debug=False)

# server = pywsgi.WSGIServer(('127.0.0.1', 5000), app)
# server.serve_forever()
